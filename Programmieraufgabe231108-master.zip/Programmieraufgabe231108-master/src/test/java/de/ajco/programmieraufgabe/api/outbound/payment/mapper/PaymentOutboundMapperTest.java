package de.ajco.programmieraufgabe.api.outbound.payment.mapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import de.ajco.programmieraufgabe.api.outbound.payment.dto.SaleDto;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.domain.payment.model.RatingType;
import de.ajco.programmieraufgabe.domain.payment.model.Sale;

class PaymentOutboundMapperTest {

	@Test
	void testSaleMapping_ToDomain() {
		Sale source = buildSale();

		SaleDto mapped = PaymentOutboundMapper.saleToSaleDto(source);

		assertEquals(source.getAmount(), mapped.getAmount());
		assertEquals(source.getCustomerId(), mapped.getCustomerId());
		assertEquals(source.getRating().name(), mapped.getRating());
		assertEquals(source.getSalesId(), mapped.getSalesId());
	}

	@Test
	void testSaleMapping_Null() {
		assertNull(PaymentOutboundMapper.saleToSaleDto(null));
	}

	@ParameterizedTest
	@EnumSource(value = RatingTypeEntity.class)
	void testRatingMapping_ToDomain(RatingTypeEntity rating) {
		assertEquals(rating.name(), PaymentOutboundMapper.ratingToDto(rating));
	}

	@Test
	void testRatingMapping_Null() {
		assertNull(PaymentOutboundMapper.ratingToDto(null));
	}

	private Sale buildSale() {
		Sale saleEntity = new Sale("AA4711", 4712L);
		saleEntity.setAmount(BigDecimal.ONE);
		saleEntity.setRating(RatingType.RECURRENT);
		return saleEntity;
	}

}
