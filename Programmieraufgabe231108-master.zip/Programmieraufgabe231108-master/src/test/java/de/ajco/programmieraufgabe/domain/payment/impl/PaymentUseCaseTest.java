package de.ajco.programmieraufgabe.domain.payment.impl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import jakarta.mail.MessagingException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import de.ajco.programmieraufgabe.api.outbound.payment.PaymentClient;
import de.ajco.programmieraufgabe.api.outbound.payment.dto.SaleDto;
import de.ajco.programmieraufgabe.api.outbound.sale.SaleRepository;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleEntity;

@ExtendWith(MockitoExtension.class)
class PaymentUseCaseTest {

	@Mock
	private SaleRepository saleRepository;

	@Mock
	private PaymentClient paymentClient;

	@InjectMocks
	private PaymentUseCase underTest;

	@Test
	void testTransferPayment() throws MessagingException {
		List<SaleEntity> sales = new ArrayList<>();
		sales.add(buildSaleEntity(4711));
		sales.add(buildSaleEntity(4712));
		sales.add(buildSaleEntity(4713));

		when(saleRepository.findAll()).thenReturn(sales);

		int transferred = underTest.transferPayment();

		verify(paymentClient, times(3)).sendSale(any(SaleDto.class));
	}

	private SaleEntity buildSaleEntity(int id) {
		SaleEntity saleEntity = new SaleEntity();
		saleEntity.setAmount(BigDecimal.ONE);
		saleEntity.setCustomerId(Long.valueOf(id));
		saleEntity.setRating(RatingTypeEntity.RECURRENT);
		saleEntity.setSalesId("AA4712");
		return saleEntity;
	}

}
