package de.ajco.programmieraufgabe.api.outbound.sale;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleEntity;
import de.ajco.programmieraufgabe.app.Application;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = Application.class)
@AutoConfigureMockMvc
class SaleRepositoryTest {

	@Autowired
	private SaleRepository underTest;

	@Test
	void testFindAll() {
		List<SaleEntity> result = underTest.findAll();

		assertEquals(3, result.size());
	}

	@Test
	void testFindBySalesIdAndCustomerId() {
		SaleEntity result = underTest.findBySalesIdAndCustomerId("AA4711", 14L);

		assertEquals(4711L, result.getSalesId());
		assertEquals(14L, result.getCustomerId());
	}

}
