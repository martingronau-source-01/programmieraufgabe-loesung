package de.ajco.programmieraufgabe.api.outbound.sale;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleEntity;
import de.ajco.programmieraufgabe.domain.payment.model.Sale;

class SaleOutboundMapperTest {

	private SaleOutboundMapper underTest = null;

	@Test
	void testSaleMapping_ToDomain() {
		SaleEntity source = buildSaleEntity();

		Sale mapped = underTest.saleEntityToDomain(source);

		assertEquals(source.getAmount(), mapped.getAmount());
		assertEquals(source.getCustomerId(), mapped.getCustomerId());
		assertEquals(source.getRating().name(), mapped.getRating().name());
		assertEquals(source.getSalesId(), mapped.getSalesId());
	}

	@Test
	void testSaleMapping_Null() {
		assertNull(underTest.saleEntityToDomain(null));
	}

	@ParameterizedTest
	@EnumSource(value = RatingTypeEntity.class)
	void testRatingMapping_ToDomain(RatingTypeEntity rating) {
		assertEquals(rating.name(), underTest.ratingToDomain(rating).name());
	}

	@Test
	void testRatingMapping_Null() {
		assertNull(underTest.ratingToDomain(null));
	}

	private SaleEntity buildSaleEntity() {
		SaleEntity saleEntity = new SaleEntity();
		saleEntity.setAmount(BigDecimal.ONE);
		saleEntity.setCustomerId(4711L);
		saleEntity.setRating(RatingTypeEntity.RECURRENT);
		saleEntity.setSalesId("AA4712");
		return saleEntity;
	}

}
