package de.ajco.programmieraufgabe.api.inbound.payment.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.http.HttpStatus;

/**
 * Response class to return a {@link HttpStatus} and a count for payment.
 */
public class PaymentResponse {

	private HttpStatus httpStatus;

	private Integer count;

	private PaymentResponse(HttpStatus httpStatus, Integer count) {
		this.httpStatus = httpStatus;
		this.count = count;
	}

	public static PaymentResponse ofOk(int count) {
		return new PaymentResponse(HttpStatus.OK, count);
	}

	public static PaymentResponse ofError(HttpStatus httpStatus) {
		return new PaymentResponse(httpStatus, null);
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public Integer getCount() {
		return count;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
