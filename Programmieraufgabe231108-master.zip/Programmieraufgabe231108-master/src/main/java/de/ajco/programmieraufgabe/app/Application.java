package de.ajco.programmieraufgabe.app;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

/**
 * Spring Boot main application to start the application.
 */
@SpringBootApplication(scanBasePackages = { Application.AJCO_PROGRAMMIERAUFGABE_PACKAGE })
public class Application {

	private static final Logger LOG = LoggerFactory.getLogger(Application.class);

	public static final String AJCO_PROGRAMMIERAUFGABE_PACKAGE = "de.ajco.programmieraufgabe";

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
		return args -> {

			LOG.info("Let's inspect the beans provided by ProgrammierAufgabe application:");

			String[] beanNames = ctx.getBeanDefinitionNames();
			Arrays.sort(beanNames);
			Arrays.stream(beanNames).map(ctx::getBean)
					.filter(bean -> bean.getClass().getPackage().getName().startsWith(AJCO_PROGRAMMIERAUFGABE_PACKAGE))
					.map(bean -> bean.getClass().getSimpleName()).filter(name -> !name.startsWith("Application"))
					.forEach(LOG::info);
		};
	}

}