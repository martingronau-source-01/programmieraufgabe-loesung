package de.ajco.programmieraufgabe.api.inbound.payment;

import javax.inject.Inject;

import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import de.ajco.programmieraufgabe.api.inbound.payment.model.PaymentResponse;
import de.ajco.programmieraufgabe.domain.payment.PaymentPort;

/**
 * Rest api providing methods to handle payment process.
 */
@RestController
public class PaymentController {

	private static final Logger LOG = LoggerFactory.getLogger(PaymentController.class);

	@Inject
	private PaymentPort paymentPort;

	@GetMapping("/startPaymentTransfer")
	public PaymentResponse startPaymentTransfer() {
		PaymentResponse response;
		try {
			int count = paymentPort.transferPayment();
			response = PaymentResponse.ofOk(count);
		} catch (RuntimeException e) {
			LOG.error("Error whily processing payments.", e);
			response = PaymentResponse.ofError(HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (MessagingException e) {
            throw new RuntimeException(e);
        }
        return response;
	}

	@GetMapping("/findToBeTransferred")
	public PaymentResponse findToBeTransferred() {
		PaymentResponse response;
		try {
			int count = paymentPort.findToBeTransferred();
			response = PaymentResponse.ofOk(count);
		} catch (RuntimeException e) {
			LOG.error("Error whily processing request.", e);
			response = PaymentResponse.ofError(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}