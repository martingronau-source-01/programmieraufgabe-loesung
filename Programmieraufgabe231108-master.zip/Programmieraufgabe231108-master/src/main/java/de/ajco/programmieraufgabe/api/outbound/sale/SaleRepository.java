package de.ajco.programmieraufgabe.api.outbound.sale;

import java.util.List;

import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleStatusEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleEntity;

/**
 * Repository to handle {@link SaleEntity}.
 */
@Repository
public interface SaleRepository extends CrudRepository<SaleEntity, Long> {

	@Override
	SaleEntity save(SaleEntity saleEntity);

	@Override
	List<SaleEntity> findAll();

	/**
	 * Get a {@link SaleEntity} by saleId and customerId.
	 * 
	 * @param salesId
	 * @param customerId
	 * @return {@link SaleEntity} or <code>null</code>, if none found.
	 */
	SaleEntity findBySalesIdAndCustomerId(String salesId, long customerId);

	/**
	 * Get  {@link List<SaleEntity>} by status.
	 *
	 * @param saleStatusEntity
	 * @return {@link List<SaleEntity>} or <code>null</code>, if none found.
	 */
	List<SaleEntity> findByStatus(SaleStatusEntity saleStatusEntity);
}
