package de.ajco.programmieraufgabe.domain.payment.model;

import java.util.Objects;

public class Role {
    private int id = 0;
    private String name = "";
    private String title = "";
    private String description = "";
    private Integer roleType = null;

    public Role() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Role(int id, String name, String title, String description, int roleType) {
        super();
        this.id = id;
        this.name = name;
        this.title = title;
        this.description = description;
        this.setRoleType(roleType);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Role role)) return false;
        return getId() == role.getId() && Objects.equals(getName(), role.getName()) && Objects.equals(getTitle(),
                role.getTitle()) && Objects.equals(getDescription(), role.getDescription())
                && Objects.equals(getRoleType(), role.getRoleType());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getTitle(), getDescription(), getRoleType());
    }

    @Override
    public String toString() {
        return "Role{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", roleType=" + roleType +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRoleType() {
        return roleType;
    }

    public void setRoleType(int roleType) {
        this.roleType = roleType;
    }

}
