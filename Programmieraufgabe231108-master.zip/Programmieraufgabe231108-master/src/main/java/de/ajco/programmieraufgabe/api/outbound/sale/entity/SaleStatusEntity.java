package de.ajco.programmieraufgabe.api.outbound.sale.entity;

/**
 * Represents the sale status in the database.
 */
public enum SaleStatusEntity {

	TO_BE_TRANSFERRED, TRANSFERRED

}
