package de.ajco.programmieraufgabe.api.outbound.sale.entity;

/**
 * Represents the rating in the database.
 */
public enum RatingTypeEntity {

	STRATEGIC("strategic"), RECURRENT("recurrent"), TEMPORARY("temporary");;

	public String getValue() {
		return value;
	}

	private final String value;

	RatingTypeEntity(String value) {
		this.value = value;
	}


}
