package de.ajco.programmieraufgabe.domain.payment.model;

public enum RoleType {
    NO_ROLE(0), GUEST_ROLE(1), MODERATOR_ROLE(2), CEO_ROLE(3), ADMIN_ROLE(4), SUPERADMIN_ROLE(5);

    private final int value;

    RoleType(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
