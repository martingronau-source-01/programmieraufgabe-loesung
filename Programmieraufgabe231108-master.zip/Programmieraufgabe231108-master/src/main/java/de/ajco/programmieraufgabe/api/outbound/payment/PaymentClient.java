package de.ajco.programmieraufgabe.api.outbound.payment;

import de.ajco.programmieraufgabe.api.outbound.payment.dto.SaleDto;
import jakarta.mail.MessagingException;

/**
 * Client to transfer sales to payment system.
 */
public interface PaymentClient {

	/**
	 * Transfers a sale to payment system.
	 *
	 * @param saleDto to be sent.
	 */
	void sendSale(SaleDto saleDto);

}
