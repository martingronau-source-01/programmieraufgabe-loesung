package de.ajco.programmieraufgabe.api.outbound.employee.entity;

import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleStatusEntity;
import jakarta.persistence.*;

@Entity
@Table(name = "role")
public class RoleEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String name;
    @Column
    private String title;
    @Column
    private String description;
    @Enumerated(EnumType.ORDINAL)
    @Column
    private RatingTypeEntity ratingType;

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RatingTypeEntity getRatingType() {
        return ratingType;
    }

    public void setRatingType(RatingTypeEntity ratingType) {
        this.ratingType = ratingType;
    }

}
