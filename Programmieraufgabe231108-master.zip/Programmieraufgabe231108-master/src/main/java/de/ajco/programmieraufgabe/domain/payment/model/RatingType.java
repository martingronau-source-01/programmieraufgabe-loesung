package de.ajco.programmieraufgabe.domain.payment.model;

/**
 * Representation of rating type in the domain.
 */
public enum RatingType {

	STRATEGIC, RECURRENT, TEMPORARY;

}
