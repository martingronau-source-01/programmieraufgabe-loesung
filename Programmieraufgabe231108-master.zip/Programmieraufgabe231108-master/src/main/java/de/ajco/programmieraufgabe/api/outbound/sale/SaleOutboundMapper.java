package de.ajco.programmieraufgabe.api.outbound.sale;

import java.util.Map;

import com.google.common.collect.ImmutableMap;

import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleEntity;
import de.ajco.programmieraufgabe.domain.payment.model.RatingType;
import de.ajco.programmieraufgabe.domain.payment.model.Sale;

/**
 * Mapping of {@link Sale} and {@link SaleEntity}.
 */
public final class SaleOutboundMapper {

	//@formatter:off
	private static final Map<RatingTypeEntity, RatingType> RATING_DOMAIN_MAP = ImmutableMap.<RatingTypeEntity, RatingType>builder()
			.put(RatingTypeEntity.RECURRENT, RatingType.RECURRENT)
			.put(RatingTypeEntity.STRATEGIC, RatingType.STRATEGIC)
			.put(RatingTypeEntity.TEMPORARY, RatingType.TEMPORARY)
			.build();
	//@formatter:on

	private SaleOutboundMapper() {
		// private
	}

	/**
	 * Map a {@link SaleEntity} into a {@link Sale}.
	 * 
	 * @param saleEntity {@link SaleEntity}
	 * @return {@link Sale}
	 */
	public static Sale saleEntityToDomain(SaleEntity saleEntity) {
		Sale sale = new Sale(saleEntity.getSalesId(), saleEntity.getCustomerId());
		sale.setAmount(saleEntity.getAmount());
		sale.setRating(ratingToDomain(saleEntity.getRating()));
		return sale;
	}

	/**
	 * Map a Rating into an {@link RatingType}.
	 * 
	 * @param rating Rating
	 * @return {@link RatingType}
	 */
	public static RatingType ratingToDomain(RatingTypeEntity rating) {
		return RATING_DOMAIN_MAP.getOrDefault(rating, null);
	}

}
