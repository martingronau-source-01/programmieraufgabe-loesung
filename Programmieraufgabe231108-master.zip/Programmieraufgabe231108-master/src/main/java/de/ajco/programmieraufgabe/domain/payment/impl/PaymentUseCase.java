package de.ajco.programmieraufgabe.domain.payment.impl;

import java.util.List;

import javax.inject.Inject;

import de.ajco.programmieraufgabe.api.outbound.employee.EmployeeRepository;
import de.ajco.programmieraufgabe.api.outbound.payment.service.MailSendService;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleStatusEntity;
import jakarta.mail.MessagingException;
import org.springframework.stereotype.Component;

import de.ajco.programmieraufgabe.api.outbound.payment.PaymentClient;
import de.ajco.programmieraufgabe.api.outbound.payment.mapper.PaymentOutboundMapper;
import de.ajco.programmieraufgabe.api.outbound.sale.SaleOutboundMapper;
import de.ajco.programmieraufgabe.api.outbound.sale.SaleRepository;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.SaleEntity;
import de.ajco.programmieraufgabe.domain.payment.PaymentPort;

@Component
public class PaymentUseCase implements PaymentPort {

	private final SaleRepository saleRepository;

	private final EmployeeRepository employeeRepository;

	private final PaymentClient paymentClient;

	@Inject
	public PaymentUseCase(SaleRepository saleRepository, EmployeeRepository employeeRepository, PaymentClient paymentClient) {
		this.saleRepository = saleRepository;
		this.employeeRepository = employeeRepository;
		this.paymentClient = paymentClient;
	}

	@Override
	public int transferPayment() throws MessagingException {
		List<SaleEntity> sales = saleRepository.findAll();

		sales.stream().map(SaleOutboundMapper::saleEntityToDomain).map(PaymentOutboundMapper::saleToSaleDto)
				.filter( s -> s != null  && !s.getSalesId().isEmpty())
				.forEach(paymentClient::sendSale);

		MailSendService mailSendService = new MailSendService();
		mailSendService.setEmployeeRepository(employeeRepository);

		int iTransfererred = 0;
		//--------------------------------
		for(SaleEntity saleEntity : sales) {
			saleEntity.setStatus(SaleStatusEntity.TRANSFERRED);
			saleRepository.save(saleEntity);

			if(saleEntity.getRating().toString().toLowerCase().equals(RatingTypeEntity.STRATEGIC.getValue())) {
				mailSendService.setSaleDto(PaymentOutboundMapper.saleToSaleDto(SaleOutboundMapper.saleEntityToDomain(saleEntity)));
				mailSendService.sendSubmitMessageToCEOStrategicSalesAboutRecurrentSales();
			}

			iTransfererred++;
		}

		return iTransfererred;
	}

	@Override
	public int findToBeTransferred() {
		return saleRepository.findByStatus(SaleStatusEntity.TO_BE_TRANSFERRED).size();
	}

}
