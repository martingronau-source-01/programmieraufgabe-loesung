package de.ajco.programmieraufgabe.domain.payment.model;

import java.math.BigDecimal;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Representation of a sale in the domain.
 */
public class Sale {

	private final String salesId;

	private final long customerId;

	private RatingType rating;

	private BigDecimal amount;

	public Sale(String saleId, long customerId) {
		this.salesId = saleId;
		this.customerId = customerId;
	}

	public String getSalesId() {
		return salesId;
	}

	public long getCustomerId() {
		return customerId;
	}

	public RatingType getRating() {
		return rating;
	}

	public void setRating(RatingType rating) {
		this.rating = rating;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
