package de.ajco.programmieraufgabe.api.outbound.payment.service;

import de.ajco.programmieraufgabe.api.outbound.employee.EmployeeRepository;
import de.ajco.programmieraufgabe.api.outbound.employee.entity.EmployeeEntity;
import de.ajco.programmieraufgabe.api.outbound.payment.dto.SaleDto;
import de.ajco.programmieraufgabe.app.config.Common;
import de.ajco.programmieraufgabe.domain.payment.model.Employee;
import de.ajco.programmieraufgabe.domain.payment.model.RoleType;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import lombok.Getter;

import java.io.InputStream;
import java.time.LocalDate;
import java.util.*;

@Getter
public class MailSendService {

    private String emailFromAdress = "";
    private List<String> emailRecients = null;

    private String emailRecipient = "";
    private String messageSubject = "";
    private String messageBodyHtml = "";
    private String messageBodyPlain = "";

    private List<String> emailAttachments = null;

    private String emailContentType = "text/html;";

    private String emailDescription = "";
    private Session session = null;

    @Getter
    private boolean hasAttachment = false;

    @Getter
    private SaleDto saleDto = null;
    @Getter
    private Employee employee = null;

    private EmployeeRepository employeeRepository;

    public MailSendService() {
        super();
        initialize();
    }

    public MailSendService(Employee employee, SaleDto saleDto, boolean hasAttachment) {
        this();
        this.saleDto = saleDto;
        this.employee = employee;
        this.hasAttachment = hasAttachment;
    }

    public MailSendService(String emailFromAdress, List<String> emailRecients, String emailRecipient,
                           String messageSubject, String messageBodyHtml, String messageBodyPlain,
                           List<String> emailAttachments, String emailContentType, String emailDescription) {
        this();
        this.emailFromAdress = emailFromAdress;
        this.emailRecients = emailRecients;
        this.emailRecipient = emailRecipient;
        this.messageSubject = messageSubject;
        this.messageBodyHtml = messageBodyHtml;
        this.messageBodyPlain = messageBodyPlain;
        this.emailAttachments = emailAttachments;
        this.emailContentType = emailContentType;
        this.emailDescription = emailDescription;
    }

    public EmployeeRepository getEmployeeRepository() {
        return employeeRepository;
    }

    public void setEmployeeRepository(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public String getEmailFromAdress() {
        return emailFromAdress;
    }

    public void setEmailFromAdress(String emailFromAdress) {
        this.emailFromAdress = emailFromAdress;
    }

    public List<String> getEmailRecients() {
        return emailRecients;
    }

    public void setEmailRecients(List<String> emailRecients) {
        this.emailRecients = emailRecients;
    }

    public String getEmailRecipient() {
        return emailRecipient;
    }

    public void setEmailRecipient(String emailRecipient) {
        this.emailRecipient = emailRecipient;
    }

    public String getMessageSubject() {
        return messageSubject;
    }

    public void setMessageSubject(String messageSubject) {
        this.messageSubject = messageSubject;
    }

    public String getMessageBodyHtml() {
        return messageBodyHtml;
    }

    public void setMessageBodyHtml(String messageBodyHtml) {
        this.messageBodyHtml = messageBodyHtml;
    }

    public String getMessageBodyPlain() {
        return messageBodyPlain;
    }

    public void setMessageBodyPlain(String messageBodyPlain) {
        this.messageBodyPlain = messageBodyPlain;
    }

    public List<String> getEmailAttachments() {
        return emailAttachments;
    }

    public void setEmailAttachments(List<String> emailAttachments) {
        this.emailAttachments = emailAttachments;
    }

    public String getEmailContentType() {
        return emailContentType;
    }

    public void setEmailContentType(String emailContentType) {
        this.emailContentType = emailContentType;
    }

    public String getEmailDescription() {
        return emailDescription;
    }

    public void setEmailDescription(String emailDescription) {
        this.emailDescription = emailDescription;
    }

    public boolean isHasAttachment() {
        return hasAttachment;
    }

    public void setHasAttachment(boolean hasAttachment) {
        this.hasAttachment = hasAttachment;
    }

    public SaleDto getSaleDto() {
        return saleDto;
    }

    public void setSaleDto(SaleDto saleDto) {
        this.saleDto = saleDto;
    }

    protected void initialize() {
        try {
            this.session = MailSendSourceHelper.getMailSesssion();
            if (this.saleDto == null) {
                this.saleDto = new SaleDto();
            }
            if (this.employee == null) {
                this.employee = new Employee();
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException(ex.getMessage());
        }

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MailSendService that)) return false;
        return Objects.equals(getEmailFromAdress(), that.getEmailFromAdress()) && Objects.equals(getEmailRecients(),
                that.getEmailRecients()) && Objects.equals(getEmailRecipient(), that.getEmailRecipient())
                && Objects.equals(getMessageSubject(), that.getMessageSubject()) && Objects.equals(getMessageBodyHtml(),
                that.getMessageBodyHtml()) && Objects.equals(getMessageBodyPlain(), that.getMessageBodyPlain())
                && Objects.equals(getEmailAttachments(), that.getEmailAttachments())
                && Objects.equals(getEmailContentType(), that.getEmailContentType())
                && Objects.equals(getEmailDescription(), that.getEmailDescription());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEmailFromAdress(), getEmailRecients(), getEmailRecipient(), getMessageSubject(),
                getMessageBodyHtml(), getMessageBodyPlain(), getEmailAttachments(), getEmailContentType(),
                getEmailDescription());
    }

    @Override
    public String toString() {
        return "MailSendService{" +
                "emailFromAdress='" + emailFromAdress + '\'' +
                ", emailRecients=" + emailRecients +
                ", emailRecipient='" + emailRecipient + '\'' +
                ", messageSubject='" + messageSubject + '\'' +
                ", messageBodyHtml='" + messageBodyHtml + '\'' +
                ", messageBodyPlain='" + messageBodyPlain + '\'' +
                ", emailAttachments=" + emailAttachments +
                ", emailContentType='" + emailContentType + '\'' +
                ", emailDescription='" + emailDescription + '\'' +
                '}';
    }


    public void sendSubmitMessageToCEOStrategicSalesAboutRecurrentSales() throws MessagingException {

        List<EmployeeEntity> employeeEntities = employeeRepository.findByRoleType(RoleType.CEO_ROLE.getValue());
        EmployeeEntity employeeEntity = employeeEntities.get(0);

        setEmailRecipient(employeeEntity.getEmail());
        setEmailFromAdress(Common.DEFAULT_MAIL_FROM_ADDRESS);

        setMessageSubject("EMail to CEO for strategic sales when processing and publish recurrent sales!");
        setEmailContentType("text/html;");

        StringBuilder sbMessageBody = new StringBuilder("<div class=\"mailtext\">")
                .append("<p stype='margin-top: 4rem'>").append(employeeEntity.getCompanyName()).append("</p>")
                .append("<p>").append(employeeEntity.getFirstName()).append(" ").append(employeeEntity.getLastName())
                .append("</p>").append("<p>").append(employeeEntity.getStreet()).append("</p>")
                .append("<p>").append(employeeEntity.getZipcode()).append(" ")
                .append(employeeEntity.getLocation()).append("</p>")
                .append("<p>").append(employeeEntity.getPhone()).append("</p>")
                .append("<p>").append(employeeEntity.getEmail()).append("</p>")
                .append("<p style='margin-top: 2rem; margin-right: 0; margin-bottom: 5rem; margin-left: 24rem;'>")
                .append(employeeEntity.getLocation()).append(", ")
                .append(LocalDate.now().format(Common.CUSTOM_FORMATTER_GERMAN_SHORT)).append("</p>")
                .append("<p>good day ").append(employeeEntity.getFirstName()).append(" ")
                .append(employeeEntity.getLastName()).append(",</p>")
                .append("<p style='margin-top:1.75rem'>with this email we are informing you in your role ")
                .append("as CEO for Strategic Sales regarding Sale '").append(saleDto.getSalesId()).append("'</p>")
                .append("<p>of €").append(saleDto.getFormattedAmount())
                .append(" about the processing and publication of recurring sales ")
                .append("to a service to be displayed on our website.</p>")
                .append("<p style='margin-top: 1.5rem'>We look forward to hearing from you and remain</p>")
                .append("<p style='margin-top: 4rem'>best regards</p>")
                .append("<p style='margin-top: 1.5rem'>your System Administration</p>")
                .append(".</div");

        setMessageBodyHtml(sbMessageBody.toString());
        sendEMail();
    }

    public void sendEMail() {

        Message message = new MimeMessage(session);

        try {

            if (this.getEmailFromAdress().isEmpty()) {
                this.setEmailFromAdress(Common.DEFAULT_MAIL_FROM_ADDRESS);
            }

            message.setFrom(new InternetAddress(getEmailFromAdress()));

            if (this.getEmailRecipient().isEmpty()) {
                this.setEmailRecipient(employee.getEmail());
            }

            message.setRecipients(
                    Message.RecipientType.TO, InternetAddress.parse(this.getEmailRecipient())
            );
            message.setSubject(getMessageSubject());

            MimeBodyPart mimeBodyPart = new MimeBodyPart();
            mimeBodyPart.setContent(this.emailContentType.equals("text/html;") ? messageBodyHtml : messageBodyPlain,
                    getEmailContentType() + "charset=" + MailSendSourceHelper.sendCharset);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(mimeBodyPart);

            message.setContent(multipart);
            Transport.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }


    }

}
