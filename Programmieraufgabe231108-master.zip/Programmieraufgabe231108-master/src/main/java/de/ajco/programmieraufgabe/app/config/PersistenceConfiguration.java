package de.ajco.programmieraufgabe.app.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EntityScan(basePackages = "de.ajco.programmieraufgabe.api.outbound")
@EnableJpaRepositories(basePackages = "de.ajco.programmieraufgabe.api.outbound")
public class PersistenceConfiguration {

	// activates automatic scan of entities and repositories.

}
