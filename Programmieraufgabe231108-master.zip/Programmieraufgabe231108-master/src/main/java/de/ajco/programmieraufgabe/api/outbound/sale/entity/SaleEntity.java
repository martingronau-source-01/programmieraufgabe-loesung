package de.ajco.programmieraufgabe.api.outbound.sale.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Represents a sale in the database.
 */
@Entity
@Table(name = "sale")
public class SaleEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column
	private String salesId;

	@Column
	private Long customerId;

	@Enumerated(EnumType.STRING)
	@Column
	private RatingTypeEntity rating;

	@Column
	private BigDecimal amount;

	@Enumerated(EnumType.STRING)
	@Column
	private SaleStatusEntity status;

	public Long getId() {
		return id;
	}

	public String getSalesId() {
		return salesId;
	}

	public void setSalesId(String salesId) {
		this.salesId = salesId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public RatingTypeEntity getRating() {
		return rating;
	}

	public void setRating(RatingTypeEntity rating) {
		this.rating = rating;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public SaleStatusEntity getStatus() {
		return status;
	}

	public void setStatus(SaleStatusEntity status) {
		this.status = status;
	}

}