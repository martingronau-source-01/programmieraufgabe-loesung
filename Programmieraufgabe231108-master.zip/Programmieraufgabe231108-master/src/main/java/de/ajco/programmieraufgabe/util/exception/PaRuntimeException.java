package de.ajco.programmieraufgabe.util.exception;

public class PaRuntimeException extends RuntimeException {

	public PaRuntimeException(String message) {
		super(message);
	}

	public PaRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

}
