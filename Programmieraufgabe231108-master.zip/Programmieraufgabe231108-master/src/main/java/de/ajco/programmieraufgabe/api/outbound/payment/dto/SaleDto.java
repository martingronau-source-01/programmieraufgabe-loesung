package de.ajco.programmieraufgabe.api.outbound.payment.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

import lombok.Getter;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Dto to hand sales to payment system.
 */
@Getter
public class SaleDto implements Serializable {

    private String salesId;

    private long customerId;

    private String rating;

    private BigDecimal amount;

    private String formattedAmount;

    public String getFormattedAmount() {
        double dAmount = amount.doubleValue();
        formattedAmount = Math.round(dAmount) != dAmount ?
                String.format(Locale.US, "%,.2f", amount.doubleValue()) :
                String.format(Locale.US, "%,.0f", amount.doubleValue());

        return formattedAmount;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public String toFormatttedString() {

        return "['" +
                salesId + '\'' +
                ", '" + rating.toLowerCase() + '\'' +
                ", '" + getFormattedAmount() + "', " + String.format("%03d", customerId) +
                "]";
    }
}
