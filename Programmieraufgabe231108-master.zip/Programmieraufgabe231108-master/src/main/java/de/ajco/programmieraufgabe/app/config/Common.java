package de.ajco.programmieraufgabe.app.config;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Common {
    public static final DateTimeFormatter CUSTOM_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final DateTimeFormatter CUSTOM_FORMATTER_SHORT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter CUSTOM_FORMATTER_GERMAN_SHORT = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    public static final String DEFAULT_MAIL_FROM_ADDRESS = "martin.gronau@futuristen.education";

    public static final String CREATOR = "MG";
    public static final String CREATED = LocalDateTime.now().format(CUSTOM_FORMATTER);

    public Common() {
        super();
    }

}
