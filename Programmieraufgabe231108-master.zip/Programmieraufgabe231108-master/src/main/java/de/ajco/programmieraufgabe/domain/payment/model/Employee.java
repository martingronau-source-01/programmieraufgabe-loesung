package de.ajco.programmieraufgabe.domain.payment.model;

import java.util.Objects;

public class Employee {

    private int id = 0;
    private String firstName = "";
    private String lastName = "";
    private String companyName = "";
    private String birthDate;

    private String street = "";
    private String zipcode = "";
    private String location = "";
    private String email = "";


    private String phone = "";

    private int roleId;

    public Employee() {
        super();
    }

    public Employee(int id, String firstName, String lastName, String birthDate, String street, String zipcode,
                    String location, String email, String phone) {
        this(firstName, lastName, birthDate, street, zipcode, location, email, phone);
        this.id = id;
    }

    public Employee(String firstName, String lastName, String birthDate, String street, String zipcode, String location,
                    String email, String phone) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.street = street;
        this.zipcode = zipcode;
        this.location = location;
        this.email = email;
        this.phone = phone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee employee)) return false;
        return getId() == employee.getId() && Objects.equals(getFirstName(), employee.getFirstName())
                && Objects.equals(getLastName(), employee.getLastName()) && Objects.equals(getCompanyName(),
                employee.getCompanyName()) && Objects.equals(getBirthDate(), employee.getBirthDate())
                && Objects.equals(getStreet(), employee.getStreet()) && Objects.equals(getZipcode(),
                employee.getZipcode()) && Objects.equals(getLocation(), employee.getLocation())
                && Objects.equals(getEmail(), employee.getEmail()) && Objects.equals(getPhone(), employee.getPhone());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getFirstName(), getLastName(), getCompanyName(), getBirthDate(), getStreet(),
                getZipcode(), getLocation(), getEmail(), getPhone());
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", companyName='" + companyName + '\'' +
                ", birthDate='" + birthDate + '\'' +
                ", street='" + street + '\'' +
                ", zipcode='" + zipcode + '\'' +
                ", location='" + location + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
