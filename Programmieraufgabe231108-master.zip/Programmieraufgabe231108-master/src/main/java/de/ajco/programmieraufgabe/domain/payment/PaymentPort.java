package de.ajco.programmieraufgabe.domain.payment;

import jakarta.mail.MessagingException;

public interface PaymentPort {

	/**
	 * Transfers open sales to the payment.
	 * 
	 * @return count of successful transferred sales
	 */
	public int transferPayment() throws MessagingException;

	/**
	 * Finds all in status TO_BE_TRANSFERED and returns count.
	 * 
	 * @return count of all in status TO_BE_TRANSFERED
	 */
	public int findToBeTransferred();

}
