package de.ajco.programmieraufgabe.api.outbound.employee;

import de.ajco.programmieraufgabe.api.outbound.employee.entity.EmployeeEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository to handle {@link EmployeeEntity}.
 */
@Repository
public interface EmployeeRepository extends CrudRepository<EmployeeEntity, Long> {

    @Override
    List<EmployeeEntity> findAll();

    @Override
    Optional<EmployeeEntity> findById(Long id);

    @Query(value = "SELECT e.id, e.first_name, e.last_name , e.company_name, e.birth_date, e.street, "
            + "e.zipcode, e.location, e.email, e.phone, e.role_id  FROM employee e "
            + "LEFT OUTER JOIN role r ON e.role_id = r.id "
            + "WHERE r.role_type = :roleType "
            + "ORDER BY e.id", nativeQuery = true)
    List<EmployeeEntity> findByRoleType(@Param("roleType") int roleType);
}
