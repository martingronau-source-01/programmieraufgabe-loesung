package de.ajco.programmieraufgabe.api.outbound.payment.mapper;

import de.ajco.programmieraufgabe.api.outbound.payment.dto.SaleDto;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import de.ajco.programmieraufgabe.domain.payment.model.Sale;

/**
 * Mapping of {@link Sale} and {@link SaleDto}.
 */
public final class PaymentOutboundMapper {

	private PaymentOutboundMapper() {
		// private
	}

	/**
	 * Map a {@link Sale} into a {@link SaleDto}.
	 * 
	 * @param sale {@link Sale}
	 * @return {@link SaleDto}
	 */
	public static SaleDto saleToSaleDto(Sale sale) {

		SaleDto saleDto = new SaleDto();

		saleDto.setSalesId(sale.getSalesId());
		saleDto.setAmount(sale.getAmount());
		saleDto.setRating(sale.getRating().toString());
		saleDto.setCustomerId(sale.getCustomerId());

		return saleDto;
	}

	/**
	 * Map a {@link RatingTypeEntity} into a String.
	 * 
	 * @param rating RatingTypeEntity
	 * @return String value of provided rating type
	 */
	public static String ratingToDto(RatingTypeEntity rating) {
		return rating.toString();
	}

}
