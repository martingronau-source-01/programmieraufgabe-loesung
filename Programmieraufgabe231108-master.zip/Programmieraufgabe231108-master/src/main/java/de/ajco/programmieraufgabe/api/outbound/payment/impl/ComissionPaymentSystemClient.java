package de.ajco.programmieraufgabe.api.outbound.payment.impl;

import de.ajco.programmieraufgabe.api.outbound.payment.service.MailSendService;
import de.ajco.programmieraufgabe.api.outbound.sale.entity.RatingTypeEntity;
import jakarta.mail.MessagingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import de.ajco.programmieraufgabe.api.outbound.payment.PaymentClient;
import de.ajco.programmieraufgabe.api.outbound.payment.dto.SaleDto;
import de.ajco.programmieraufgabe.util.exception.PaRuntimeException;

@Component
public class ComissionPaymentSystemClient implements PaymentClient {

	@Override
	public void sendSale(SaleDto saleDto) {
		if (saleDto == null) {
			throw new PaRuntimeException("SaleDto cannot be null.");
		}
		System.out.println(saleDto.toFormatttedString());
		System.out.println(">>> Sending sale '"+saleDto.getSalesId()+"' to the Commission Payment System");

		if(saleDto.getRating().toLowerCase().equals(RatingTypeEntity.RECURRENT.getValue())) {
			System.out.println(">>> Publish sale '"+saleDto.getSalesId()+"' to the intranet page");;
		} else if(saleDto.getRating().toLowerCase().equals(RatingTypeEntity.STRATEGIC.getValue())) {
			System.out.println(">>> Sending email to CEO for sale '"+saleDto.getSalesId()+"' ");;

		}
	}

}
