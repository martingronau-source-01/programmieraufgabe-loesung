DROP TABLE IF EXISTS SALE;
CREATE TABLE SALE (
	id INTEGER NOT NULL AUTO_INCREMENT,
	sales_id VARCHAR(255) NOT NULL,
	rating VARCHAR(20) NOT NULL,
	amount NUMBER(12,3) NOT NULL,
	customer_id INTEGER NOT NULL,
	status VARCHAR(20) NULL,
	PRIMARY KEY(id)
);

DROP TABLE IF EXISTS EMPLOYEE;
CREATE TABLE EMPLOYEE (
                            id INTEGER NOT NULL AUTO_INCREMENT,
                            first_name varchar(255) DEFAULT NULL,
                            last_name varchar(255) DEFAULT NULL,
                            company_name varchar(255) DEFAULT NULL,
                            birth_date varchar(255) DEFAULT NULL,
                            street varchar(255) DEFAULT NULL,
                            zipcode varchar(255) DEFAULT NULL,
                            location varchar(255) DEFAULT NULL,
                            email varchar(255) DEFAULT NULL,
                            phone varchar(255) DEFAULT NULL,
                            role_id INTEGER  NULL,
                            PRIMARY KEY(id)
);

DROP TABLE IF EXISTS ROLE;
CREATE TABLE ROLE (
                      id INTEGER NOT NULL AUTO_INCREMENT,
                      name varchar(255) DEFAULT NULL,
                      title varchar(255) DEFAULT NULL,
                      description varchar(255) DEFAULT NULL,
                      role_type INTEGER NULL,
                      PRIMARY KEY(id)
);