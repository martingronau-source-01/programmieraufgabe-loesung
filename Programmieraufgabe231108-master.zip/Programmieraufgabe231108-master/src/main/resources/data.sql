INSERT INTO SALE (sales_id, rating, amount, customer_id, status) VALUES ('AA4711', 'TEMPORARY', 299.98, 14, 'TO_BE_TRANSFERRED');
INSERT INTO SALE (sales_id, rating, amount, customer_id, status) VALUES ('AA9345', 'STRATEGIC', 5011111.00, 755, 'TO_BE_TRANSFERRED');
INSERT INTO SALE (sales_id, rating, amount, customer_id, status) VALUES ('AA8922', 'RECURRENT', 745.99, 78, 'TO_BE_TRANSFERRED');

INSERT INTO ROLE (id, name, title, description, role_type) VALUES(1, 'guest', 'Guest', 'Rolle Gast', 1);
INSERT INTO ROLE (id, name, title, description, role_type) VALUES(2, 'modertor', 'Moderator', 'Rolle Moderator', 1);
INSERT INTO ROLE (id, name, title, description, role_type) VALUES(3, 'ceo', 'ceo', 'Rolle CEO', 3);
INSERT INTO ROLE (id, name, title, description, role_type) VALUES(4, 'admin', 'Admin', 'Rolle Administrator', 0);
INSERT INTO ROLE (id, name, title, description, role_type) VALUES(5, 'superadmin', 'Supderadmin', 'Rolle Super-Administrator', 1);

INSERT INTO EMPLOYEE (id, first_name, last_name, company_name, birth_date, street, zipcode, location, email, phone, role_id) VALUES(1, 'Katja', 'Sirotkin', 'reuse GmbH', '2023-08-22 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'fl-kontakt@tutanota.com', '+49 163 2380475',2);
INSERT INTO EMPLOYEE (id, first_name, last_name, company_name, birth_date, street, zipcode, location, email, phone, role_id) VALUES(2, 'Martin', 'Gronau', NULL, '1961-10-13 00:00:00', 'Weidenhäuser Straße 92', '35037', 'Marburg', 'martin.gronau@jugsoftware.de', '+49 163 2380475', 2);
INSERT INTO EMPLOYEE (id, first_name, last_name, company_name, birth_date, street, zipcode, location, email, phone, role_id) VALUES(3, 'Marta', 'Gorenstein', 'ajco solutions GmbH', '2023-11-07', 'Mannheimer Straße 105', '68535', 'Edingen-Neckarhausen', 'marta.gorenstein@ajco.de', '+49 163 2380475',2);
INSERT INTO EMPLOYEE (id, first_name, last_name, company_name, birth_date, street, zipcode, location, email, phone, role_id) VALUES(4, 'Bruce', 'Dickinson', '', '2023-09-06 00:00:00', 'Eddygasse 2', '2323', 'Entenhausen', 'bruce@gmail.com', '+666 666',1);
INSERT INTO EMPLOYEE (id, first_name, last_name, company_name, birth_date, street, zipcode, location, email, phone, role_id) VALUES(5, 'Victor', 'Küpper', 'ajco solutions GmbH', '2023-11-07', 'Mannheimer Straße 105', '68535', 'Edingen-Neckarhausen', 'victor.kuepper@ajco.de', '+34343',3);
COMMIT;